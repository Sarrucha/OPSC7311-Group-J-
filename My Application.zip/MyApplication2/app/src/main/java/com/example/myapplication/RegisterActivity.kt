package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.myapplication.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth


class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth= FirebaseAuth.getInstance()

        val emailEdt = findViewById<EditText>(R.id.inputUsername)
        val passwordEdt = findViewById<EditText>(R.id.inputPasswordlog)
        val registerBtn = findViewById<Button>(R.id.btnRegister)

        // calling on click listener for register button.
        binding.btnRegister.setOnClickListener {

            val emailEdt = binding.inputUsername.text.toString()
            val pass = binding.inputPassword.text.toString()
            val confirmPass = binding.confirmPassword.text.toString()
            // to check if the user fields are empty or not.
            if (emailEdt.isNotEmpty() && pass.isNotEmpty() && confirmPass.isNotEmpty()) {
                if (pass == confirmPass){
                    if (emailEdt.isNotEmpty() && pass.isNotEmpty()) {
                       /* firebaseAuth.createUserWithEmailAndPassword(emailEdt, pass)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {

                                    // Successfully signed in
                                    val user = firebaseAuth.currentUser
                                    // Do something with the user
                                    val i = Intent(this@RegisterActivity, HomePageActivity::class.java)
                                    startActivity(i)
                                } else {
                                    // Sign in failed
                                    Log.w("TAG", "SignIn failed.", task.exception)
                                }
                            }*/
                        firebaseAuth.createUserWithEmailAndPassword(emailEdt,pass).addOnCompleteListener{
                            val i = Intent(this@RegisterActivity, HomePageActivity::class.java)
                            startActivity(i)
                        }


                    } else {

                        Toast.makeText(this, "Empty fields are not allowed", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener

                    }
                    /*firebaseAuth.createUserWithEmailAndPassword(emailEdt, pass).addOnCanceledListener {

                            // starting new activity.
                            val i = Intent(this@RegisterActivity, HomePageActivity::class.java)
                            startActivity(i)

                    }*/

                }else{
                    Toast.makeText(this, "Password fields are not mathcing", Toast.LENGTH_SHORT).show()
                }
            } else {

                Toast.makeText(this, "Empty fields are not allowed", Toast.LENGTH_SHORT).show()

            }
        }

        /*val button = findViewById<Button>(R.id.btnAlready)
        button.setOnClickListener {
            // Handle button click

            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
            startActivity(intent)
        }*/
    }
}