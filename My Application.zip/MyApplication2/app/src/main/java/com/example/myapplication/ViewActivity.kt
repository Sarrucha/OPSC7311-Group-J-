package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import com.example.myapplication.R.id.home

class ViewActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var entryAdapter: EntryAdapter
    private val entryList: MutableList<Entry> = mutableListOf()

    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)

        val print = findViewById<Button>(R.id.printName)

        print.setOnClickListener{



            // Initialize ListView
            listView = findViewById(R.id.listView)


            // Sample data for testing
            entryList.add(Entry("POE", "High-demand school project", "Urgent", "2012-10-16", "2012-12-04"))
            entryList.add(Entry("Wedding", "Client wedding needs to be planned", "Not Urgent", "2012-06-21", "2012-12-16"))
            entryList.add(Entry("Playlist", "High-end playlist for a birthday party", "Urgent", "2013-01-06", "2012-12-04"))


            // Initialize Adapter
            entryAdapter = EntryAdapter(this.entryList, entryList)
            listView.adapter = entryAdapter

            // at last we close our cursor

            this.finish()
        }
        val home :Button
        home = findViewById<Button>(R.id.home)

        home.setOnClickListener {
            val i = Intent(this@ViewActivity, HomePageActivity::class.java)
            startActivity(i)
        }

    }
}


