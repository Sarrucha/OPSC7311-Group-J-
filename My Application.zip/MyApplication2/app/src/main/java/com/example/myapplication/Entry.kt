package com.example.myapplication

data class Entry(
    val name: String = "",
    val description: String = "",
    val category: String,
    val startDate: String,
    val endDate: String
)
