package com.example.myapplication


import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.util.Log
import androidx.media3.common.util.UnstableApi
import com.google.firebase.firestore.FirebaseFirestore


val categories = arrayOf("Urgent", "Not Urgent")


class CreateTimeSheetActivity : AppCompatActivity()

{
    private lateinit var firestore: FirebaseFirestore

    lateinit var entries: List<Entry>



    @OptIn(UnstableApi::class)
    fun addEntry(entry: Entry) {
        firestore = FirebaseFirestore.getInstance()

        firestore.collection("entries")
            .add(entry)
            .addOnSuccessListener { documentReference ->
                android.util.Log.d("TAG", "DocumentSnapshot added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w("TAG", "Error adding document", e)
            }
    }


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_time_sheet)

        val spin = findViewById<Spinner>(R.id.catSpinner)
        val arrayAdapter =
            ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, categories)
        spin.adapter = arrayAdapter
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Toast.makeText(
                    applicationContext,
                    "selected category is =" + categories.toString(),
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }


        val saveBtn = findViewById<Button>(R.id.TimeSheetEntrySaveButton)
        saveBtn.setOnClickListener {
            // Handle button click

            // below we have created
            // a new DBHelper class,
            // and passed context to it


            // creating variables for values
            // in name and age edit texts

            val name = findViewById<TextView>(R.id.nameoftimesheetentry).toString()

            // below is the variable for description column
            val description = findViewById<TextView>(R.id.EntryDescription).toString()

            // below is the variable for description column
            val category = findViewById<Spinner>(R.id.catSpinner).toString()

            val startDate = findViewById<TextView>(R.id.startDateEdit).toString()

            val endDate = findViewById<TextView>(R.id.endDateEdit).toString()

            // calling method to add
            // name to our database
            val newEntry= Entry(name, description, category, startDate, endDate)
            entries.toMutableList().add(newEntry)


            // Toast to message on the screen
            Toast.makeText(this, name + " added to database", Toast.LENGTH_LONG).show()

            // at last, clearing edit texts
            findViewById<TextView>(R.id.nameoftimesheetentry).clearComposingText()
           // enterAge.text.clear()


            val intent = Intent(this@CreateTimeSheetActivity, HomePageActivity::class.java)
            startActivity(intent)
        }

    }
}


