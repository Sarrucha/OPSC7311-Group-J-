package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.myapplication.databinding.ActivityLoginBinding
import com.example.myapplication.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var firebaseAuth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        binding.textViewSignUp.setOnClickListener{
            // starting new activity.
            val i = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(i)
        }

        binding.btnLogin.setOnClickListener {
            val emailEdt = binding.inputUsername.text.toString()
            val pass = binding.inputPasswordlog.text.toString()
            var count : Int =0

            while (count<=0) {
                if (emailEdt.isNotEmpty() && pass.isNotEmpty()) {
                    firebaseAuth.signInWithEmailAndPassword(emailEdt, pass)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                count+=1
                                // Successfully signed in
                                val user = firebaseAuth.currentUser
                                // Do something with the user
                                val i = Intent(this@LoginActivity, HomePageActivity::class.java)
                                startActivity(i)
                            } else {
                                // Sign in failed
                                Log.w("TAG", "SignIn failed.", task.exception)
                            }
                        }


                } else {

                    Toast.makeText(this, "Empty fields are not allowed", Toast.LENGTH_SHORT).show()

                }
            }
        }

    }
}