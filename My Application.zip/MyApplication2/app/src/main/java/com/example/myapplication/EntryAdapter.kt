package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.widget.BaseAdapter

class EntryAdapter(private val context: MutableList<Entry>, private val entryList: List<Entry>) : BaseAdapter(){

    class EntryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.entryName)
        val descriptionTextView: TextView = itemView.findViewById(R.id.entryDescription)
        val categoryTextView: TextView = itemView.findViewById(R.id.Category)
        val startDateTextView: TextView = itemView.findViewById(R.id.sDate)
        val endDateTextView: TextView = itemView.findViewById(R.id.eDate)
    }

    fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntryViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        return EntryViewHolder(itemView)
    }



    fun onBindViewHolder(holder: EntryViewHolder, position: Int) {
        val entry = entryList[position]
        holder.nameTextView.text = entry.name
        holder.descriptionTextView.text = entry.description
        holder.categoryTextView.text = entry.category
        holder.startDateTextView.text = entry.startDate
        holder.endDateTextView.text = entry.endDate
    }

    fun getItemCount() = entryList.size
    override fun getCount(): Int {
        TODO("Not yet implemented")
    }

    override fun getItem(position: Int): Any {
        TODO("Not yet implemented")
    }

    override fun getItemId(position: Int): Long {
        TODO("Not yet implemented")
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        TODO("Not yet implemented")
    }
}



